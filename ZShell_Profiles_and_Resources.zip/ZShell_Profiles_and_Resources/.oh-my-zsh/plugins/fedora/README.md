The fedora plugin is deprecated. Use the [dnf plugin](https://github.com/robbyrussell/oh-my-zsh/tree/master/plugins/dnf) instead.
